#!/usr/bin/env python
from discord import Intents, Status, Activity, ActivityType, Object, File
from discord.utils import get
from os import listdir, getcwd
from discord.ext import commands, tasks
from time import time
from datetime import datetime
import os
import discord
from re import match
from paramiko import SSHClient, SFTPClient
from con.sftp import createSSHClient
from con.config import Config
from UI.UI import create_dynamic_image
from stats.PLAYER import PlayerTemplates, process_player_logs, update_player, handle_player_disconnect, update_player_count
from stats.MISSION import MissionTemplates, process_mission_logs, update_mission
from stats.SERVER import ServerTemplates, process_server_logs, update_server_status, update_server_status_role
from typing import List, Dict, Tuple


class ReforgerStats(commands.Bot):
    def __init__(self, config: Config, prefix: str, intents: discord.Intents, mode: str = "remote"):
        super().__init__(command_prefix=prefix, intents=intents)
        self.config = config
        self.mode: str = mode  # "local" or "remote"
        self.players: List[Dict] = []
        self.gamertags: List[str] = []
        self.disconnected_players = set()
        self.player_count = 0
        self.ssh: SSHClient = None
        self.sftp: SFTPClient = None
        self.missions: List[Tuple[str, str]] = []
        self.server_status = None
        self.current_status_text = ""
        self.message_id: str = ""
        self.log_dir: str = ""
        self.log_index: int = -1
        self.last_read_position: int = 0  # Utolsó olvasási pozíció
        self._running: bool = False
        self.cogs_loaded = False
        self.event_channel = None  # A változó a csatorna tárolásához


    async def ensure_ssh_connection(self):
        if self.ssh is None or self.sftp is None or not self.ssh.get_transport().is_active():
            try:
                self.sftp, self.ssh = createSSHClient(self.config)
                print("SSH kapcsolat sikeresen létrejött.")
            except Exception as e:
                print(f"Hiba az SSH kapcsolat létrehozásakor: {e}")

    async def read_local_file(self, file_path: str) -> List[str]:
        new_lines = []
        try:
            with open(file_path, "r") as file:
                file.seek(self.last_read_position)
                new_lines = file.readlines()
                self.last_read_position = file.tell()
        except Exception as e:
            print(f"Hiba a helyi fájl olvasásakor: {e}")
        return new_lines

    async def read_file(self, file_path: str) -> List[str]:
        try:
            with self.sftp.open(file_path) as file:
                return file.readlines()
        except Exception as e:
            print(f"Hiba történt a fájl olvasásakor: {e}")
            return []

    # A legutóbb módosított könyvtár lekérdezése
    async def _get_latest_directory(self, remote_path: str) -> str:
        latest_dir = None
        latest_time = None

        try:
            directories = self.sftp.listdir(remote_path)
        except Exception as e:
            print(f"Error listing directories in {remote_path}: {e}")
            return ""

        for directory in directories:
            try:
                attrs = self.sftp.lstat(f"{remote_path}/{directory}")
                mod_time = datetime.fromtimestamp(attrs.st_mtime)
                if latest_time is None or mod_time > latest_time:
                    latest_time = mod_time
                    latest_dir = directory
            except Exception as e:
                print(f"Error processing directory {directory}: {e}")

        return latest_dir if latest_dir else ""

    async def on_ready(self):
        try:
            print(f"Bot csatlakozott: {self.user}")
            await self.load_cogs()
        except Exception as e:
            print(f"Hiba történt a bot csatlakozása után: {e}")

    async def load_cogs(self: commands.Bot):
        try:
            if self.cogs_loaded:
                return
            print("Coggok betöltése...")
            for filename in listdir(f"{getcwd()}/con"):
                if filename.endswith('event.py'):
                    cog = filename[:-3]
                    try:
                        await self.load_extension(f"con.{cog}")
                        print(f"Cog {filename} successfully loaded")
                    except Exception as e:
                        print(f"Hiba a cog betöltésekor ({filename}): {type(e).__name__}: {e}")
        except Exception as e:
            print(f"Hiba történt a coggok betöltése közben: {e}")

        try:
            guild = Object(id=self.config.GUILD)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            print(f"[{guild.id}] Synced {len(synced)} command(s)")
        except Exception as e:
            print(f"Hiba történt a parancsok szinkronizálása közben: {e}")

        self.cogs_loaded = True

    async def send_or_update_message(self, content: str, file: discord.File):
        """Üzenet küldése vagy meglévő üzenet frissítése a csatornában."""
        if not self.event_channel:
            print("Nincs beállítva csatorna az eseményhez.")
            return

        try:
            if self.message_id:
                message = await self.event_channel.fetch_message(self.message_id)
                await message.edit(content=content, attachments=[file])
            else:
                message = await self.event_channel.send(content=content, file=file)
                self.message_id = message.id
        except discord.NotFound:
            print("A korábbi üzenet nem található, új üzenet küldése.")
            message = await self.event_channel.send(content=content, file=file)
            self.message_id = message.id
        except Exception as e:
            print(f"Hiba az üzenet küldése vagy szerkesztése során: {e}")


    @tasks.loop(seconds=10)
    async def scraper(self):
        try:
            # Fájl olvasása a megfelelő módszerrel
            if self.mode == "local":
                log_path = "console.log"
                lines = await self.read_local_file(log_path)
            elif self.mode == "remote":
                await self.ensure_ssh_connection()
                remote_path = "/reforger/logs"
                if not self.log_dir:
                    self.log_dir = await self._get_latest_directory(remote_path)
                file_path = f"{remote_path}/{self.log_dir}/console.log"
                lines = await self.read_file(file_path)
            else:
                print(f"Ismeretlen mód: {self.mode}")
                return

            # Feldolgozás, ha vannak új sorok
            new_lines = lines[self.log_index + 1:] if self.log_index + 1 < len(lines) else []
            if new_lines:
                self.log_index = len(lines) - 1

                await process_player_logs(self, new_lines)
                await update_player_count(self)
                await process_server_logs(self, new_lines)
                await process_mission_logs(self, new_lines)

                # Állapot frissítése
                player_count = self.player_count
                status_text = f"{player_count}" if self.server_status == "online" else "❌ Offline"
                activity_type = discord.ActivityType.playing if self.server_status == "online" else discord.ActivityType.watching
                status_enum = discord.Status.online if self.server_status == "online" else discord.Status.dnd

                if self.current_status_text != status_text:
                    self.current_status_text = status_text
                    await self.change_presence(activity=discord.Activity(type=activity_type, name=status_text), status=status_enum)

            # Kép generálás, ha a szerver online
            if self.server_status == "online":
                server_name = ""
                max_players = 0
                ping_number = 0
                player_count = len(self.players)
                missions_data = self.missions if self.missions else [("", "Unknown")]
                image_path = "UI/out/output_image.png"

                create_dynamic_image(self.players, server_name, missions_data, player_count, max_players, ping_number, image_path)

                if os.path.exists(image_path):
                    with open(image_path, "rb") as f:
                        picture = discord.File(f)
                else:
                    print(f"File not found: {image_path}")
                    return

                # Üzenet küldése vagy frissítése a csatornában
                if self.event_channel:
                    try:
                        message = await self.event_channel.fetch_message(self.message_id) if self.message_id else None
                        if message:
                            await message.edit(content="Szerver monitor:", attachments=[picture])
                        else:
                            new_message = await self.event_channel.send(content="Szerver monitor:", file=picture)
                            self.message_id = new_message.id
                    except discord.NotFound:
                        new_message = await self.event_channel.send(content="Szerver monitor:", file=picture)
                        self.message_id = new_message.id
                else:
                    print("Nincs beállítva csatorna az eseményhez.")

        except Exception as e:
            print(f"Error during scraper execution: {e}")


    @scraper.before_loop
    async def before_scraper(self):
        try:
            await self.wait_until_ready()
        except Exception as e:
            print(f"Error before scraper loop: {e}")