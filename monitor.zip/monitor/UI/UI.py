import os
import json

from pythonping import ping
from PIL import Image, ImageDraw, ImageFont

# Font beállítások
font_path = "UI/font/Roboto-Regular.ttf"  # font fájl elérési útvonal
font_size = 16
font = ImageFont.truetype(font_path, font_size)

# Színek
white_color = (255, 255, 255)
gray_color = (190, 190, 190)
yellow_color = (255,220,105)
yellow_bar_color = (230, 170, 80,230)
transparent_bar_color1 = (0, 0, 0, 220)
transparent_bar_color21 = (0, 0, 0, 60)
transparent_bar_color22 = (0, 0, 0, 130)



""" FRANE """
# Keret (sáv) rajzolása
def draw_frame(image, position, size, color):
    frame = Image.new("RGBA", size, color)
    image.paste(frame, position, frame)



""" TEXT """
# Szöveg rajzolása egy dobozban
def draw_text_box(draw, text, position, alignment='center', color=(255, 255, 255), font_size=None):
    # Betöltés egy betűtípus a megadott mérettel, ha megadva van
    font_to_use = font
    if font_size:
        font_to_use = ImageFont.truetype(font_path, font_size)

    text = str(text)  # Szöveg konvertálása szöveggé a TypeError elkerülése érdekében
    text_width = font_to_use.getlength(text)
    x, y = position

    if alignment == 'center':
        draw.text((x - text_width // 2, y), text, font=font_to_use, fill=color)
    elif alignment == 'left':
        draw.text((x, y), text, font=font_to_use, fill=color)
    elif alignment == 'right':
        draw.text((x - text_width, y), text, font=font_to_use, fill=color)



""" ICON """
# Ikon hozzáadása
def add_icon(image, icon_path, position, size=(32, 32), rotate_angle=0, keep_original_color=False, overlay_color=None):
    if os.path.exists(icon_path):
        icon = Image.open(icon_path).convert("RGBA").resize(size)

        if rotate_angle != 0:
            icon = icon.rotate(rotate_angle, expand=True)

        if overlay_color:  # Átlátszó színátfedés alkalmazása
            color_overlay = Image.new("RGBA", icon.size, overlay_color)
            icon = Image.composite(color_overlay, icon, icon)

        if keep_original_color:
            image.paste(icon, (int(position[0]), int(position[1])), icon)
        else:  # Szürke színűre konvertálás
            gray_icon = Image.new("RGBA", icon.size, (190, 190, 190, 0))
            pixels = icon.load()
            gray_pixels = gray_icon.load()

            for i in range(icon.size[0]):
                for j in range(icon.size[1]):
                    r, g, b, a = pixels[i, j]
                    if a > 0:
                        gray_pixels[i, j] = (190, 190, 190, a)

            image.paste(gray_icon, (int(position[0]), int(position[1])), gray_icon)

# Nyilak hozzáadása (fel és le)
def add_arrows(image, up_position, down_position, size=(12, 12)):
    add_icon(image, 'UI/icon/arrow/arrow.png', up_position, size=size)
    add_icon(image, 'UI/icon/arrow/arrow.png', down_position, size=size, rotate_angle=180)



""" SCENARIO """
# Betöltjük a scenarios.json fájlt
with open("UI/scenarios.json", "r", encoding="utf-8") as file:
    scenario_to_image = json.load(file)

def add_mission_box(image, icon_path, box_size=(400, 220), border_thickness=5, border_color=(transparent_bar_color22)):
    width, height = image.size
    box_x = width - box_size[0] - 20
    box_y = 140

    border_size = (box_size[0] + 2 * border_thickness, box_size[1] + 2 * border_thickness)
    border = Image.new("RGBA", border_size, border_color)
    image.paste(border, (box_x - border_thickness, box_y - border_thickness), border)
    add_icon(image, icon_path, (box_x, box_y), size=box_size, keep_original_color=True)

# Mission box a scenario alapján
def add_mission_box_for_scenario(image, missions, box_size=(400, 220), border_thickness=5, border_color=(transparent_bar_color22)):
    missions = missions.strip().upper()  # Tisztítás és nagybetűre alakítás
    mission_image_path = scenario_to_image.get(missions, "UI/mission/default.png")
    add_mission_box(image, mission_image_path, box_size=box_size, border_thickness=border_thickness, border_color=border_color)
    #print(f"mission box hozzáadása a missionshoz: {missions} kép elérési útvonallal: {mission_image_path}")



""" PLAYERS """
# Frissített függvény a nevek rajzolására
def draw_player_names_in_columns(draw, frame, player_names, num_columns=3, row_height=20, margin=20, spacing=20, text_color=(255, 255, 255)):
    frame_x, frame_y = frame['x'], frame['y']
    max_rows = (frame['height'] - 2 * margin) // row_height  # Maximális sorok egy oszlopon belül

    # Számold ki dinamikusan az oszlopok szélességét
    available_width = frame['width'] - 2 * margin - (num_columns - 1) * spacing
    column_width = available_width // num_columns

    # Inicializáld a változókat az oszlopokhoz és sorokhoz
    column_index = 0
    row_index = 0

    for i, name in enumerate(player_names):
        if row_index >= max_rows:  # Ha az oszlop megtelt, lépj a következő oszlopra
            column_index += 1
            row_index = 0  # Sorindex visszaállítása

        if column_index >= num_columns:  # Ha az oszlopok száma elérte a maximumot, állj meg
            break

        # Dinamikusan számold ki az oszlop x-pozícióját
        column_x = frame_x + margin + column_index * (column_width + spacing)

        # Számold ki az y-pozíciót a sorhoz
        y_position = frame_y + margin + row_index * row_height

        # Nevet rajzold ki az oszlopba
        draw_text_box(draw, name, (column_x, y_position), alignment='left', color=text_color)

        # Következő sorba lépés
        row_index += 1


# Oszlopok keretének rajzolása
def draw_columns_in_frame(image, frame, num_columns=3, margin=20, spacing=20, column_color=(200, 200, 200)):
    # Számold ki dinamikusan az oszlopok szélességét
    available_width = frame['width'] - 2 * margin - (num_columns - 1) * spacing
    column_width = available_width // num_columns

    for i in range(num_columns):
        # Dinamikusan számold ki az oszlop x-pozícióját
        column_x = frame['x'] + margin + i * (column_width + spacing)
        column_y = frame['y'] + margin
        column_height = frame['height'] - 2 * margin
        column_size = (column_width, column_height)

        # Rajzold meg az oszlop keretét
        draw_frame(image, (column_x, column_y), column_size, column_color)


""" PING """
def get_average_ping(ip_address, count=5):
    response = ping(ip_address, count=count)
    average_ping = sum([r.time_elapsed_ms for r in response]) / count
    return int(average_ping)  # Csak az egész részt adja vissza



""" UI """
# Fő UI függvény dinamikus elrendezéssel
def create_dynamic_image(players: list[dict], server_name, missions, player_count, max_players, ping_number, output_file="UI/out/output_image.png"):
    base_image = Image.open('UI/bg/MenuBackgroundBlank_UI.png').convert("RGB")
    draw = ImageDraw.Draw(base_image)

    server_name = "ArmaHu Server - Hungary"
    max_players = 48
    sorted_players = sorted(players, key=lambda a: a["gamertag"])
    #player_names = "\n".join([f"{player['gamertag']}" for player in sorted_players])
    player_names = [player['gamertag'] for player in sorted_players]
    mission_name = " - ".join([mission[0] for mission in missions])

    width, height = base_image.size
    bar_height = 50
    frame_position1_y = 10
    icon_position1_y  = frame_position1_y + 5
    arrow_position_x = 15
    arrow_position_up_y = 20
    arrow_position_down_y = arrow_position_up_y + 15
    left_icon_position_x = 30

    # Frame és pozíciók
    frame_positions = {
        'bar1': {'x': 0, 'y': 2, 'width': width, 'height': 5, 'color': yellow_bar_color},
        'bar2': {'x': 0, 'y': frame_position1_y, 'width': width, 'height': bar_height, 'color': transparent_bar_color1},
        'bar3': {'x': 0, 'y': 70, 'width': width, 'height': 5, 'color': transparent_bar_color21},
        'bar4': {'x': 0, 'y': 75, 'width': width, 'height': 40, 'color': transparent_bar_color22},
        # Kép magassága alapján dinamikusan számított magasság
        'frame1': {'x': 0, 'y': 125, 'width': 720, 'height': height - 125, 'color': transparent_bar_color21},
        'frame2': {'x': 740, 'y': 125, 'width': 440, 'height': height - 125, 'color': transparent_bar_color21},
    }

    # Keretrajzok
    for frame in frame_positions.values():
        draw_frame(base_image, (frame['x'], frame['y']), (frame['width'], frame['height']), frame['color'])

    #Hozzáadja a thumbs-up ikont 50px-re balra
    add_icon(base_image, 'UI/icon/thumbs/thumbs-up.png', (left_icon_position_x, icon_position1_y), size=(32, 32))

    # Rögzített nyíl pozíciók (a szöveg pozícionálásának alapját képezik)
    arrow_positions = {
        'Name': {'x': 140},
        'Scenario': {'x': width - 290},
        'Players': {'x': width - 160},
        'Ping': {'x': width - 45},
    }

    # Rajzolja meg a fejléc címkéket és nyilakat
    for label, pos in arrow_positions.items():
        draw_text_box(draw, label, (pos['x'], 25), alignment='right')

        # Nyilak pozíciója (10px-re jobbra minden fejléctől)
        up_arrow_pos = (pos['x'] + arrow_position_x, arrow_position_up_y)
        down_arrow_pos = (pos['x'] + arrow_position_x, arrow_position_down_y)
        add_arrows(base_image, up_arrow_pos, down_arrow_pos)

    add_icon(base_image, 'UI/icon/favourite/favourite.png', (left_icon_position_x, frame_positions['bar4']['y'] + 5), size=(32, 32))

    # Használjuk az sftp_host értéket
    sftp_host = os.getenv("SFTP_HOST")
    ping_number = get_average_ping(sftp_host)

    # Dinamikus ikon a ping szám alapján
    if ping_number <= 50:
        ping_icon = 'UI/icon/ping/ping-high.png'
    elif ping_number <= 100:
        ping_icon = 'UI/icon/ping/ping-medium.png'
    else:
        ping_icon = 'UI/icon/ping/ping-low.png'

    row_data = [
        # Soradatok dinamikus pozícionálással
        {'text': server_name, 'label': 'Name','fixed_position': arrow_positions['Name']['x'] - font.getlength("Name")},  # Indulás a 'Name' pozíciótól
        {'text': mission_name, 'icon': 'UI/icon/modicon/modicon.png', 'label': 'Scenario'},
        {'text': f'{player_count}/{max_players}', 'label': 'Players'},
        {'text': f'{ping_number}', 'icon': 'UI/icon/ping/ping-icon.png', 'label': 'Ping'},
    ]

    # Rajzolja meg a soradatokat
    for item in row_data:
        text_color = (white_color) if item['label'] == 'Name' else (gray_color)  # Fehér a 'Name' számára, szürke a többihez

        if 'fixed_position' in item:
            # Használja a kiszámított rögzített pozíciót a 'server_name' számára
            text_position = (item['fixed_position'], frame_positions['bar4']['y'] + 10)
            draw_text_box(draw, item['text'], text_position, alignment='left', color=text_color)
        else:
            label_position = arrow_positions[item['label']]
            text_position = (label_position['x'] - 5, frame_positions['bar4']['y'] + 10)  # Módosított X a többihez

            if 'icon' in item:
                add_icon(base_image, item['icon'], (label_position['x'] + 5, frame_positions['bar4']['y'] + 5))

            add_icon(base_image, ping_icon, (arrow_positions['Ping']['x'] + 5, frame_positions['bar4']['y']), keep_original_color=True)

            draw_text_box(draw, item['text'], text_position, alignment='right', color=text_color)

    # Rajzoljuk meg az oszlopokat
    draw_columns_in_frame(base_image, frame_positions['frame1'], num_columns=3, margin=10, spacing=20, column_color=transparent_bar_color22)
    # Helyezzük a neveket az első oszlopba (pl. index 0)


    draw_player_names_in_columns(draw, frame_positions['frame1'], player_names)

    # Adja hozzá a küldetés dobozát a forgatókönyvhöz
    add_mission_box_for_scenario(base_image, mission_name)

    # Misszió neve nagyobb fehér betűkkel
    draw_text_box(draw,mission_name,(frame_positions['frame2']['x'] + 30, frame_positions['frame1']['y'] + 260),alignment='left',color=white_color,font_size=22)

    # Verzió megjelenítése 30 pixelrel lejjebb
    if missions:
        latest_mission_name, latest_mission_version = missions[-1]  # misszió verzió
        version_y = frame_positions['frame1']['y'] + 290
        draw_text_box(draw,f"v. {latest_mission_version}",(frame_positions['frame2']['x'] + 30, version_y),alignment='left',color=yellow_color,font_size = 18)


    # Mentse el a végső képet
    base_image.save(output_file)