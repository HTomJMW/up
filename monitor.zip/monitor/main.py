#!/usr/bin/env python
import asyncio
from discord import Intents
from con.config import Config
from bot.ReforgerStatsBot import ReforgerStats


async def main() -> None:
    intents = Intents.default()
    intents.message_content = True

    # Válassz üzemmódot: 'local' vagy 'remote'
    mode = "remote"  # Módosítsd 'remote'-ra, ha távoli logokkal szeretnéd használni

    bot = ReforgerStats(Config(), "!", intents, mode=mode)

    async with bot:
        await bot.start(bot.config.TOKEN)

if __name__ == "__main__":
    asyncio.run(main())