from re import match
from discord.ext import commands


# KÜLDETÉS Regex sablonok
class MissionTemplates:
    Mission = r'(?P<time>\d{2}:\d{2}:\d{2}\.\d{3}) SCRIPT\s*:\s*(?P<mission>.*)Mission version:\s*(?P<version>[\d\.]+)'

# KÜLDETÉS log feldolgozó
async def process_mission_logs(bot: commands.Bot, logs: list[str]) -> None:
    """Feldolgozza a küldetésekkel kapcsolatos naplókat."""
    for log in logs:
        mission_data = match(MissionTemplates.Mission, log)
        if mission_data:
            mission_name = mission_data.group("mission").split(":")[0]
            mission_version = mission_data.group("version")
            await update_mission(bot, mission_name, mission_version)

# KÜLDETÉS status frissítése
async def update_mission(bot: commands.Bot, mission: str, version: str) -> None:
    """Frissíti vagy hozzáadja a küldetést és annak verzióját a listába."""
    # Ellenőrizzük, hogy a küldetés már létezik-e
    if not any(mission == item[0] for item in bot.missions):
        # Ha nem létezik, hozzáadjuk a küldetést és verziót
        bot.missions.append((mission, version))  # Küldetés és verzió páros hozzáadása
        print(f"Küldetés hozzáadva: {mission}, {version}")
    else:
        print(f"Küldetés már létezik: {mission} (verzió: {version})")
