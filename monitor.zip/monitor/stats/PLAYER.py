from re import finditer
from discord.ext import commands
from typing import List


# JÁTÉKOS Regex sablonok
class PlayerTemplates:
    PlayerID = r'(?P<time>[\d:.]+)\s+NETWORK\s+: ### Updating player: PlayerId=(?P<player_id>\d+), Name=(?P<gamertag>.+?), IdentityId=(?P<player_guid>[a-f0-9-]+)'
    PlayerDisconnect = r'(?P<time>\d{2}:\d{2}:\d{2}\.\d{3})\s*DEFAULT\s*:\s*BattlEye Server:.*Player\s#\d+\s*(?P<player_name>.*?)\s*disconnected'


# JÁTÉKOS log feldolgozó
async def process_player_logs(bot: commands.Bot, logs: List[str]) -> None:
    """Feldolgozza az összes játékosokkal kapcsolatos logot."""
    for log in logs:
        try:
            # Csatlakozási események feldolgozása
            player_data = finditer(PlayerTemplates.PlayerID, log)
            for match_data in player_data:
                gamertag = match_data.group("gamertag")
                player_guid = match_data.group("player_guid")
                player_id = match_data.group("player_id")
                await update_player(bot, gamertag=gamertag, player_id=player_id, player_guid=player_guid)

            # Lecsatlakozási események feldolgozása
            disconnect_data = finditer(PlayerTemplates.PlayerDisconnect, log)
            for match_data in disconnect_data:
                gamertag = match_data.group("player_name")
                await handle_player_disconnect(bot, gamertag)

        except Exception as e:
            print(f"[HIBA] Log feldolgozása közben hiba történt: {e}")

# JÁTÉKOS állapot frissítése
async def update_player(bot: commands.Bot, gamertag: str, player_id: str = None, player_guid: str = None, disconnected: bool = False):
    """Játékos állapotának frissítése vagy hozzáadása."""
    existing_player = next((p for p in bot.players if p["gamertag"] == gamertag), None)

    if disconnected:
        if existing_player:
            print(f"Játékos lecsatlakozott: {gamertag}")
            bot.players = [p for p in bot.players if p != existing_player]  # eltávolítja a játékost
        await update_player_count(bot)  # biztosítja a frissítést a játékosok számában
        return

    if existing_player:
        existing_player["connections"] += 1
        if player_id:
            existing_player["player_id"] = player_id
        if player_guid:
            existing_player["player_guid"] = player_guid
        print(f"[DEBUG] Játékos frissítve: {gamertag}, kapcsolatok száma: {existing_player['connections']}")
    else:
        new_player = {
            "gamertag": gamertag,
            "player_id": player_id,
            "player_guid": player_guid,
            "connections": 1,
        }
        bot.players.append(new_player)
        print(f"[DEBUG] Új játékos hozzáadva: {gamertag}")

    await update_player_count(bot)

# JÁTÉKOS lecsatlakozás kezelése
async def handle_player_disconnect(bot, gamertag: str):
    """Kezeli a játékos lecsatlakozását."""
    await update_player(bot, gamertag=gamertag, disconnected=True)

# JÁTÉKOS szám frissítése
async def update_player_count(bot):
    """Frissíti a játékosok számát."""
    try:
        bot.player_count = len(bot.players)
        print(f"Játékosok száma frissítve: {bot.player_count}")
    except Exception as e:
        print(f"Hiba történt a játékosok számának frissítése közben: {e}")
