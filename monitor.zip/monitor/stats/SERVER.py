from re import match
from discord.ext import commands
import discord


# Szerver állapotát jelző Regex sablonok
class ServerTemplates:
    ServerCreated = r'(?P<time>\d{2}:\d{2}:\d{2}\.\d{3})\s+ENGINE\s+: Game (?P<online>successfully) created'
    ServerDestroyed = r'(?P<time>\d{2}:\d{2}:\d{2}\.\d{3})\s+ENGINE\s+: Game (?P<offline>destroyed)\.?'

# SERVER log feldolgozó
async def process_server_logs(bot: commands.Bot, logs: list[str]) -> None:
    """Feldolgozza a szerver állapotát, és frissíti, ha változott."""
    latest_log = None

    # Logok feldolgozása: keresés az új szerver státusz után
    for log in logs:
        if match(ServerTemplates.ServerCreated, log):
            latest_log = "online"
        elif match(ServerTemplates.ServerDestroyed, log):
            latest_log = "offline"

    # Ha az állapot változott, frissítsük
    if latest_log and latest_log != bot.server_status:
        bot.server_status = latest_log
        print(f"[DEBUG] Szerver {bot.server_status}.")
        await update_server_status(bot)
        await update_server_status_role(bot)

# SERVER status frissítése
async def update_server_status(bot: commands.Bot) -> None:
    """Frissíti a szerver állapotát és aktivitását."""
    try:
        # Online és offline státuszok beállítása
        status_map = {
            "online": (discord.Status.online, discord.ActivityType.playing, f"{bot.player_count}"),
            "offline": (discord.Status.dnd, discord.ActivityType.watching, "❌ Offline")
        }

        # Állapot frissítése
        if bot.server_status in status_map:
            status, activity_type, status_text = status_map[bot.server_status]
            activity = discord.Activity(type=activity_type, name=status_text)
            await bot.change_presence(status=status, activity=activity)
            print(f"[DEBUG] Státusz frissítése: {bot.server_status}")
        else:
            print("[DEBUG] Nem ismert státusz.")
    except Exception as e:
        print(f"Hiba történt a szerver státuszának frissítése közben: {e}")


# Szerepkör színének frissítése
async def update_server_status_role(bot: commands.Bot) -> None:
    """Frissíti a szerepkör színét a szerver állapotának megfelelően."""
    guild = bot.guilds[0]
    role = discord.utils.get(guild.roles, name="monitor")

    if not role:
        print("A(z) 'monitor' szerepkör nem található!")
        return

    # Színek beállítása állapot szerint
    colors = {
        "online": discord.Colour(0x00FF00),  # Zöld
        "offline": discord.Colour(0xFF0000)  # Piros
    }

    try:
        if bot.server_status in colors:
            await role.edit(colour=colors[bot.server_status])
            print(f"Szerepkör '{role.name}' színe {bot.server_status} módosítva.")
    except discord.Forbidden:
        print("Nincs jogosultságom a szerepkör színének módosításához!")
    except discord.HTTPException as e:
        print(f"Hiba történt a szín módosításakor: {e}")
