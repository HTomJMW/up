#!/usr/bin/env python
from discord.ext import commands
from discord import app_commands, Member, Interaction


class Event(app_commands.Group):
    def __init__(self, bot: commands.Bot, name: str, description: str):
        super().__init__(name=name, description=description)
        self.bot = bot

    def hasPermission(self, user: Member) -> bool:
        """Check if the user has the necessary admin role."""
        return any(role.id == self.bot.config.ADMIN for role in user.roles)

    async def handle_event_command(self, interaction: Interaction, action: str) -> None:
        """Handles the event start/stop logic."""
        if not self.hasPermission(interaction.user):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
            return

        if action == "start":
            if self.bot._running:
                await interaction.response.send_message("Event already started", ephemeral=True)
                return
            self.bot.event_channel = interaction.channel
            self.bot.scraper.start()
            self.bot._running = True
            await interaction.response.send_message("Starting new event Server Monitor...", ephemeral=True)

        elif action == "stop":
            if not self.bot._running:
                await interaction.response.send_message("Event already stopped", ephemeral=True)
                return
            self.bot.scraper.cancel()
            self.reset_bot_state()
            await interaction.response.send_message("Stopping event Server Monitor...", ephemeral=True)


    def reset_bot_state(self):
        """Reset bot state after stopping an event."""
        self.bot._running = False
        self.bot.log_file = ""
        self.bot.log_index = -1
        self.bot.start_time = -1
        self.bot.players.clear()  # Reset players list
        self.bot.gamertags.clear()  # Reset gamertags list
        self.bot.disconnected_players.clear()  # Reset disconnected players set
        self.bot.player_count = 0  # Reset player count
        self.bot.missions.clear()  # Reset missions list
        self.bot.server_status = None  # Reset server status
        self.bot.current_status_text = ""  # Reset current status text
        self.bot.message_id = ""  # Reset message ID
        self.bot.log_dir = ""  # Reset log directory
        self.bot.last_read_position = 0  # Reset last read position
        self.bot.event_channel = None  # Reset event channel
        self.close_ssh_connections()  # Close SSH/SFTP if open

    def close_ssh_connections(self):
        """Close SSH and SFTP connections if open."""
        if self.bot.sftp:
            self.bot.sftp.close()
        if self.bot.ssh:
            self.bot.ssh.close()
        self.bot.sftp = None
        self.bot.ssh = None

    @app_commands.command(name="start", description="Start an event Server Monitor")
    async def start(self, interaction: Interaction) -> None:
        await self.handle_event_command(interaction, "start")

    @app_commands.command(name="stop", description="Stop an event Server Monitor")
    async def stop(self, interaction: Interaction) -> None:
        await self.handle_event_command(interaction, "stop")

async def setup(bot: commands.Bot) -> None:
    bot.tree.add_command(Event(bot, name="event", description="Start or stop an event Server Monitor"))
