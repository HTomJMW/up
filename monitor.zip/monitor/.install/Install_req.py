import subprocess
import sys

# Az összes szükséges csomag listája
required_packages = [
    "discord.py",
    "paramiko",
    "python-dotenv",
    "Pillow",
    "pythonping"
]

def check_package_installed(package: str) -> bool:
    """Ellenőrzi, hogy egy csomag telepítve van-e."""
    try:
        # Ellenőrizzük a csomag telepítettségét
        subprocess.check_call([sys.executable, "-m", "pip", "show", package],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except subprocess.CalledProcessError:
        return False

def install_package(package: str) -> None:
    """Telepíti a csomagot, ha nincs telepítve."""
    try:
        print(f"{package} telepítése...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"{package} telepítve!")
    except subprocess.CalledProcessError:
        print(f"Hiba történt a {package} telepítése közben.")

def main():
    print("Kezdődhet a szükséges csomagok telepítése...")

    for package in required_packages:
        if not check_package_installed(package):
            install_package(package)
        else:
            print(f"{package} már telepítve van. Ugrás a következő csomagra.")

    print("Minden szükséges csomag telepítve!")

if __name__ == "__main__":
    main()
