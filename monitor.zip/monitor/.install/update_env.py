import os

def prompt_overwrite():
    """Kérdezi a felhasználót, hogy felülírja-e a meglévő .env fájlt."""
    while True:
        user_input = input("A '.env' fájl már létezik, de nem üres. Biztosan felül szeretnéd írni? (y/n): ").lower()
        if user_input == 'y':
            return True
        elif user_input == 'n':
            print("Kilépés...")
            return False
        else:
            print("Érvénytelen válasz. Kérlek írd be újra 'y' vagy 'n'.")

def is_env_empty(file_path):
    """Ellenőrzi, hogy a .env fájl üres-e, vagyis hogy a változók értéke üres-e."""
    try:
        with open(file_path, "r") as f:
            content = f.read().strip()
            # Ellenőrizzük, hogy az összes kulcshoz tartozó érték üres-e
            lines = content.splitlines()
            for line in lines:
                # Csak a változókat és az értékeket figyeljük, elhanyagoljuk a kommenteket és üres sorokat
                if '=' in line and not line.startswith('#'):
                    key, value = line.split('=', 1)
                    if value.strip() != '':  # Ha van adat a változóhoz, nem üres
                        return False
            return True
    except FileNotFoundError:
        return True  # Ha a fájl nem létezik, akkor üresnek tekintjük

def update_env_file():
    """Frissíti a .env fájlt, ha nem létezik, vagy ha a felhasználó beleegyezik a felülírásba."""
    env_file = ".env"

    # Ellenőrizzük, hogy létezik-e már a .env fájl
    if os.path.exists(env_file):
        # Ha létezik, ellenőrizzük, hogy üres-e
        if is_env_empty(env_file):
            print(".env fájl üres, folytatás...")
            # Ha üres a fájl, akkor a felhasználónak lehetősége van a kitöltésére
        else:
            print(".env fájl már létezik és nem üres.")
            if not prompt_overwrite():
                return  # Ha nem akarják felülírni, kilépünk
            # Ha felülírják, akkor folytatjuk a fájl frissítését
    else:
        print(".env fájl nem található. Új fájl készítése...")

    # Most lehetőséget biztosítunk a felhasználónak, hogy felvigye az adatokat
    print("\nKérlek töltsd ki az alábbi adatokat a '.env' fájlhoz:")

    discord_token = input("Discord Token: ")
    discord_guild = input("Discord Guild: ")
    admin_role = input("Admin Role: ")
    webhook = input("Webhook URL: ")

    sftp_host = input("SFTP Host: ")
    sftp_port = input("SFTP Port: ")
    sftp_username = input("SFTP Username: ")
    sftp_password = input("SFTP Password: ")

    # Ha a fájl nem létezik vagy a felhasználó beleegyezett a felülírásba, létrehozzuk vagy frissítjük a fájlt
    with open(env_file, "w") as f:
        f.write("# Discord\n\n")
        f.write(f"DISCORD_TOKEN={discord_token}\n")
        f.write(f"DISCORD_GUILD={discord_guild}\n")
        f.write(f"ADMIN_ROLE={admin_role}\n")
        f.write(f"WEBHOOK={webhook}\n\n")

        f.write("# SFTP\n\n")
        f.write(f"SFTP_HOST={sftp_host}\n")
        f.write(f"SFTP_PORT={sftp_port}\n")
        f.write(f"SFTP_USERNAME={sftp_username}\n")
        f.write(f"SFTP_PASSWORD={sftp_password}\n")

    print(f"{env_file} fájl sikeresen létrehozva vagy frissítve lett a megadott adatokkal!")

if __name__ == "__main__":
    update_env_file()
